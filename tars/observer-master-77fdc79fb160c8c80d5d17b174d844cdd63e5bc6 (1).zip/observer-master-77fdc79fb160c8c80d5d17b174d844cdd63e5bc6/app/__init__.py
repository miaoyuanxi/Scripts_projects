# coding:utf8

from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from .models import db

def create_app():
    app = Flask(__name__)

    db.init_app(app)


    from .admin import admin as admin_blueprint
    app.register_blueprint(admin_blueprint, url_prefix="/admin")

    from .api import api as api_blueprint
    app.register_blueprint(api_blueprint, url_prefix="/api")

    from .root import root as root_blueprint
    app.register_blueprint(root_blueprint)


    return app