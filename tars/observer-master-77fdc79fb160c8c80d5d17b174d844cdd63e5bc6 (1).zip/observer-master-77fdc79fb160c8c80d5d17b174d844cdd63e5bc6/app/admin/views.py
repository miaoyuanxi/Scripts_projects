# coding:utf8

from . import admin
from flask import render_template
import time


# from flask import render_template, redirect, url_for


@admin.route("/")
def index():

    return render_template("index.html",)


@admin.route("/welcome")
def welcome():
    date = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    return render_template("welcome.html", date=date)

@admin.route("/unicode")
def unicode():
    return render_template("unicode.html")

@admin.route("/job")
def job():
    return render_template("job.html")

@admin.route("/task")
def task():
    return render_template("task.html")

@admin.route("/echarts1")
def echarts1():
    return render_template("echarts1.html")
@admin.route("/echarts2")
def echarts2():
    return render_template("echarts2.html")
@admin.route("/echarts3")
def echarts3():
    return render_template("echarts3.html")
@admin.route("/echarts4")
def echarts4():
    return render_template("echarts4.html")
@admin.route("/echarts5")
def echarts5():
    return render_template("echarts5.html")
@admin.route("/echarts6")
def echarts6():
    return render_template("echarts6.html")
@admin.route("/echarts7")
def echarts7():
    return render_template("echarts7.html")
@admin.route("/echarts8")
def echarts8():
    return render_template("echarts8.html")


