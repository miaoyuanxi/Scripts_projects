# coding:utf8

from flask import Blueprint

admin = Blueprint("admin", __name__, template_folder="app", static_folder="app")

import app.admin.views