from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()

# С�����
class Task_info(db.Model):
    __tablename__ = 'task_info'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    date = db.Column(db.String(100))
    task_id = db.Column(db.Integer)
    job_id = db.Column(db.Integer)
    soft = db.Column(db.String(100))
    ip = db.Column(db.String(100))
    platform = db.Column(db.String(100))
    system = db.Column(db.String(100))

# ��ϸִ��ʱ���
class Task_exetime(db.Model):
    __tablename__ = 'task_exetime'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    date = db.Column(db.String(100))
    task_id = db.Column(db.Integer)
    job_id = db.Column(db.Integer)
    action = db.Column(db.String(200))
    start_time = db.Column(db.String(200))
    end_time = db.Column(db.String(200))
    total_time = db.Column(db.String(200))
