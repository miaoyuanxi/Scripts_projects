from . import root

from flask import redirect, url_for

@root.route("/")
def root():
    return redirect(url_for("admin.index"))
