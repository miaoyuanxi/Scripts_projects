from flask import redirect, url_for, Blueprint

root = Blueprint("root", __name__)

import app.root.rootpage